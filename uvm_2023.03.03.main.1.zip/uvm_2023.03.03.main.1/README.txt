1. Download uvm.zip in local machine, extract and open folder
2. Run file "uvm_install.bat" this will prompt to Powershell as Administrator, accept to continue, wait untill installation is finished
3. Open cmd and execute command uvm_add_utilities, follow instructions
4. Go to path C:uvm and for each folder download binary versions of corresponding utility and add it to corresponding folder (rename your version folders accordingly i.e '14_15_5', ...)
4. Open cmd and execute command uvm_use, follow instructions
5. askjdhsd
6.