function getImportantFiles() {
    $importantFiles = @(
        "README.txt", 
        "uvm_config_lib.json",
        "uvm_config.json", 
        "uvm_lib.psm1"
        "uvm_install_script.ps1", 
        "uvm_install.bat", 
        "uvm_configuration_script.ps1", 
        "uvm_configuration.bat", 
        "uvm_use_script.ps1", 
        "uvm_use.bat",
        "uvm_version.txt",
        "uvm_version.bat"
    );
    $importantFiles;
}

function getConfigFile() {
    $uvmConfigFile = "uvm_config.json";
    $uvm_config = [PSCustomObject](Get-Content ".\$($uvmConfigFile)" | Out-String | ConvertFrom-Json);
    $uvm_config;
}

function getSupportedUtilities() {
    $uvm_config = getConfigFile;
    $supportedUtilitiesTemp = $uvm_config.PSObject.Properties;
    $supportedUtilities = @();
    foreach ($supportedUtilityTemp in $supportedUtilitiesTemp) {
        $supportedUtilities = ($supportedUtilities + $supportedUtilityTemp.Value.utility);
    }
    $supportedUtilities;
}

function getEnvironmentVariablePathList() {
    [String[]]$PathList = @();
    $PathList = ($PathList + [System.Environment]::GetEnvironmentVariable("PATH", "Machine") -split "$([IO.Path]::PathSeparator)");
    $PathList;
}

function getCleanPathList([PSCustomObject]$utility, [String[]]$PathList) {
    $PathList = $PathList | Where-Object { -not ($_ -like "*$($utility.environmentVariable)*") };
    foreach ($environmentVariableExtention in $utility.environmentVariableExtentionInPath) {
        if ($environmentVariableExtention) {
            $PathList = $PathList | Where-Object { -not ($_ -like "$($utility.installationPath)\*\$($environmentVariableExtention)") }
            $PathList = $PathList | Where-Object { $_ -ne "$($utility.installationPath)\$($environmentVariableExtention)" };
        }
        else {
            $PathList = $PathList | Where-Object { -not ($_ -like "$($utility.installationPath)\*") }
            $PathList = $PathList | Where-Object { $_ -ne "$($utility.installationPath)" };
        }
    }
    $PathList;
}

function getInstalledVersionsForSelectedUtility([String]$userSelectedUtility) {
    $uvm_config = getConfigFile;
    $environmentVariable = $uvm_config.$userSelectedUtility.environmentVariable;
    $currentVersion = (Get-ChildItem Env:\$environmentVariable).value;
    $Depth = 1;
    $Path = $uvm_config.$userSelectedUtility.installationPath;
    $Levels = '/*' * $Depth;
    $installedVersions = @();
    Get-ChildItem -Directory $Path/$Levels |
    ForEach-Object { 
        $version = ($_.FullName -split '[\\/]')[ - $Depth];
        if ($currentVersion.Contains(($_.FullName -split '[\\/]')[ - $Depth])) {
            $version = "$($version) --> current ";
        }
        $installedVersions = ($installedVersions + $version);
    } | Select-Object -Unique
    $installedVersions;
}

function createInstallationDirectories() {
    $uvm_config = getConfigFile;
    $uvm_config.PSObject.Properties | ForEach-Object {
        createInstallationDirectoryForUtility($_.Value);
    }
}

function createInstallationDirectoryForUtility([PSCustomObject]$utility) {
    if (Test-Path $utility.installationPath) {
        Write-Host "Directory already exists";
    }
    else {
        New-Item -Path $utility.installationPath -ItemType Directory;
    }
}

function copyImportantFilesToUvmInstallationDirectory() {
    $uvm_config = getConfigFile;
    $importantFiles = getImportantFiles;
    foreach ($importantFile in $importantFiles) {
        Copy-Item -Path ".\$($importantFile)" -Destination $uvm_config.UVM.installationPath;
    }
}

function loadNextScript([String]$nextRunningScriptFile) {
    $uvm_config = getConfigFile;
    Set-Location "$($uvm_config.UVM.installationPath)";
    . "$($uvm_config.UVM.installationPath)\$($nextRunningScriptFile)";
}

function showSupportedUtilities() {
    Write-Host " ";
    Write-Host "Utility Version Manager (uvm) currently supports following utilities:";
    $supportedUtilities = getSupportedUtilities;
    foreach ($supportedUtility in $supportedUtilities) {
        Write-Host "- $($supportedUtility)";
    }
}

function showListOfOptionsAndReadUserSelection([String[]]$list) {
    Write-Host " ";
    Write-Host "Select an item:";
    $listPlusExit = ($list + "Exit");
    showListOfOptions($listPlusExit);
    Do {
        $answer = Read-Host -Prompt "Enter the number of the item:";
        # TODO: here we have an issue, study separetelly
        $isWrong = (-not(isValidInteger($answer))) -or 0 -or ($answer -ge $listPlusExit.length);
        if ($isWrong) {
            Write-Host "You inserted an invalid number"
        }
    } while ($isWrong)
    $selectedOption = $listPlusExit[$answer];
    $selectedOption;
}

function showListOfOptions([String[]]$list) {
    foreach ($option in $list) {
        Write-Host "- $($list.IndexOf($option)): $($option)";
    }
}

function isValidInteger ([string]$a) { 
    Try {
        $null = [Int]$a;
        if ($a.Contains(',') -or $a.Contains('.') -or $a.Contains(' ')) {
            return $false;
        }
        else {
            return $true
        }

    }
    Catch {
        return $false;
    }
}

function saveConfigFile([PSCustomObject]$uvm_config) {
    $uvmConfigFile = "uvm_config.json";
    $uvm_config | ConvertTo-Json | Out-File "$($uvm_config.UVM.installationPath)\$($uvmConfigFile)";
}

function addUtility() {
    $uvm_config = getConfigFile;
    $newUtilityName = Read-Host "Enter the name of the utility you want to add:";
    if(-not (utilityExists($newUtilityName))) {
        [string[]]$newUtiliyEnvironmentVariableExtentionInPath = @();
        $newUtiliyEnvironmentVariableExtentionInPath = Read-Host "Enter list of the environment variable extensions for Path:"
        $newUtility = @{
            $newUtilityName.ToUpper() = [PSCustomObject]@{
                utility                            = $newUtilityName.ToLower()
                environmentVariable                = "$($newUtilityName.ToUpper())_HOME"
                environmentVariableExtentionInPath = $newUtiliyEnvironmentVariableExtentionInPath.Split(',').Split(' ')
                installationPath                   = "C:\uvm\$($newUtilityName.ToLower())"
            }
        }
        $uvm_config | Add-Member $newUtility;
        saveConfigFile($uvm_config);
        createInstallationDirectoryForUtility($newUtility.$newUtilityName);
        createWindowsEnvironmentVariableForUtility($newUtility.$newUtilityName);
        addWindowsEnvironmentVariableToPathForUtility($newUtility.$newUtilityName);
        updateCurrentPowershellSessionWithEnvironmentVariablesForUtility($newUtility.$newUtilityName);
    } else {
        Write-Host "The utlity $($newUtilityName) already exists, please select a non-existing utility."
    }

}

function removeUtility() {
    $uvm_config = getConfigFile;
    $supportedUtilities = getSupportedUtilities;
    $selectedUtility = showListOfOptionsAndReadUserSelection($supportedUtilities);
    if(utilityExists($selectedUtility)) {
        $selectedUtility = $selectedUtility.ToUpper();
        [String[]]$PathList = @();
        $PathList = ($PathList + [System.Environment]::GetEnvironmentVariable("PATH", "Machine") -split "$([IO.Path]::PathSeparator)");
        $PathList = getCleanPathList $uvm_config.$selectedUtility $PathList;
        $newPath = $PathList -join "$([IO.Path]::PathSeparator)";
        [System.Environment]::SetEnvironmentVariable("PATH", $newPath, "Machine");
        [System.Environment]::SetEnvironmentVariable($uvm_config.$selectedUtility.environmentVariable, $null, [System.EnvironmentVariableTarget]::Machine);
        Remove-Item -path $uvm_config.$selectedUtility.installationPath;
        $uvm_config.PSObject.Properties.Remove($selectedUtility);
        saveConfigFile($uvm_config);
    } else {
        Write-Host "The utlity $($selectedUtility) does not exist, hence cannot be removed. Please select an existing utility."
    }
}

function utilityExists([PSCustomObject]$utility) {
    $supportedUtilities = getSupportedUtilities;
    $utilityExists = $supportedUtilities.contains($utility);

    # $utilityExists = [bool]($uvm_config.PSobject.Properties.name -match $utility);
    $utilityExists;
}

function createWindowsEnvironmentVariables() {
    $uvm_config = getConfigFile;
    $uvm_config.PSObject.Properties | ForEach-Object {
        createWindowsEnvironmentVariableForUtility($_.Value);
    }
}

function createWindowsEnvironmentVariableForUtility([PSCustomObject]$utility) {
    [System.Environment]::SetEnvironmentVariable(
        $utility.environmentVariable, 
        $utility.installationPath, 
        [System.EnvironmentVariableTarget]::Machine
    );
}

function addWindowsEnvironmentVariablesToPath() {
    $uvm_config = getConfigFile;
    $PathList = getEnvironmentVariablePathList;
    $uvm_config.PSObject.Properties | ForEach-Object {
        $PathList = addWindowsEnvironmentVariableToPathListForUtility $_.Value $PathList;
    }
    updateEnvironmentVaribalePathWithNewPathList($PathList);
}

function addWindowsEnvironmentVariableToPathForUtility([PSCustomObject]$utility) {
    $PathList = getEnvironmentVariablePathList;
    $PathList = addWindowsEnvironmentVariableToPathListForUtility $utility $PathList;
    updateEnvironmentVaribalePathWithNewPathList($PathList);
}

function updateEnvironmentVaribalePathWithNewPathList([String[]]$PathList) {
    $newPath = $PathList -join "$([IO.Path]::PathSeparator)";
    [System.Environment]::SetEnvironmentVariable("PATH", $newPath, "Machine");
}

function addWindowsEnvironmentVariableToPathListForUtility([PSCustomObject]$utility, [String[]]$PathList) {
    $PathList = getCleanPathList $utility $PathList;
    foreach ($environmentVariableExtention in $utility.environmentVariableExtentionInPath) {
        if ($environmentVariableExtention) {
            $PathList = ($PathList + "%$($utility.environmentVariable)%\$($environmentVariableExtention)");
        }
        else {
            $PathList = ($PathList + "%$($utility.environmentVariable)%");
        }
    }
    $PathList;
}

function updateCurrentPowershellSessionWithEnvironmentVariables() {
    $uvm_config = getConfigFile;
    $uvm_config.PSObject.Properties | ForEach-Object {
        updateCurrentPowershellSessionWithEnvironmentVariableForUtility($_.Value);
    }
    updateCurrentPowershellSessionWithPathEnvironmentVariable;
}

function updateCurrentPowershellSessionWithEnvironmentVariablesForUtility([PSCustomObject]$utility) {
    updateCurrentPowershellSessionWithEnvironmentVariableForUtility($utility);
    updateCurrentPowershellSessionWithPathEnvironmentVariable;
}

function updateCurrentPowershellSessionWithEnvironmentVariableForUtility([PSCustomObject]$utility) {
    [Environment]::SetEnvironmentVariable($utility.environmentVariable, [System.Environment]::GetEnvironmentVariable($utility.environmentVariable, "Machine"));
}

function updateCurrentPowershellSessionWithPathEnvironmentVariable() {
    [Environment]::SetEnvironmentVariable("PATH", [System.Environment]::GetEnvironmentVariable("PATH", "Machine"));
}

function setVersionOfUtilityToEnvironmentVariable([String]$selectedUtility, [String]$selectedVersion) {
    $uvm_config = getConfigFile;
    [System.Environment]::SetEnvironmentVariable(
        $uvm_config.$selectedUtility.environmentVariable, 
        "$($uvm_config.$selectedUtility.installationPath)\$($selectedVersion)", 
        [System.EnvironmentVariableTarget]::Machine
    );
}
