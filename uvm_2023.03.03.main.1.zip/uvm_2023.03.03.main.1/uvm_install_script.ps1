Write-Host "Current directory: $pwd"

Import-Module -Name '.\uvm_lib.psm1' -Force;

Write-Host "-------------------------------------------INSTALLATION-------------------------------------------";
createInstallationDirectories;
copyImportantFilesToUvmInstallationDirectory;
createWindowsEnvironmentVariables;
addWindowsEnvironmentVariablesToPath;
updateCurrentPowershellSessionWithEnvironmentVariables;
showSupportedUtilities;

loadNextScript("uvm_configuration_script.ps1");