Write-Host "Current directory: $pwd"

Import-Module -Name '.\uvm_lib.psm1' -Force;

Write-Host "-----------------------------------------UTILITY VERSION MANAGMENT------------------------------------------"

Do {
  $supportedUtilities = getSupportedUtilities;
  $selectedUtility = showListOfOptionsAndReadUserSelection($supportedUtilities);
  if ($selectedUtility -ne "Exit") {
    $installedVersions = getInstalledVersionsForSelectedUtility([String]$selectedUtility);
    $selectedVersion = showListOfOptionsAndReadUserSelection($installedVersions);
    if ($selectedVersion -ne "Exit") {
      setVersionOfUtilityToEnvironmentVariable $selectedUtility $selectedVersion;
      updateCurrentPowershellSessionWithEnvironmentVariables;
    }
  }
} until ($selectedUtility -eq "Exit");

Start-Process cmd;