Write-Host "Current directory: $pwd"

Import-Module -Name '.\uvm_lib.psm1' -Force;

Write-Host "-----------------------------------------SETUP UTILITIES------------------------------------------"

$tasks = @("Add", "Remove");
Do {
  showSupportedUtilities;
  $selectedTask = showListOfOptionsAndReadUserSelection($tasks);
  if($selectedTask -eq "Add")  {
    addUtility;
  } elseif ($selectedTask -eq "Remove") {
    removeUtility;
  }
} until ($selectedTask -eq "Exit");

addWindowsEnvironmentVariablesToPath;

Start-Process cmd;